#ifndef _RES_GFX_H_
#define _RES_GFX_H_

extern const Image room_0_bga;
extern const Image room_0_bgb;
extern const Image gfx_bgb1;
extern const Image gfx_bgb2;

#endif // _RES_GFX_H_
